window.STORE_CONFIG = {
  brandName: 'VÉLORA',
  logo: 'VÉLORA',
  tagline: 'Modern fashion for modern lives.',
  primaryColor: '#1C1C1C',
  accentColor: '#8B6F47',
  surfaceColor: '#FAF9F6',
  currency: '₹',
  skuPrefix: 'VL',
  orderPrefix: 'VL',
  contactEmail: 'care@velora.in',
  contactPhone: '+91 1800 890 5672',
  whatsapp: '+91 98765 43210',
  address: '42, Vittal Mallya Road, Bengaluru, Karnataka 560001',
  workingHours: 'Mon–Sat, 9:00 AM–7:00 PM IST',
  freeDeliveryThreshold: 1499,
  socialLinks: { instagram: '#', facebook: '#', youtube: '#', pinterest: '#' },
  apiBaseUrl: '/api',
  announcement: 'COMPLIMENTARY DELIVERY ABOVE ₹1,499  ·  EASY 14-DAY RETURNS',
  imageFallback: 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="800" height="1000"%3E%3Crect width="100%25" height="100%25" fill="%23E8DFD3"/%3E%3Ctext x="50%25" y="50%25" font-family="serif" font-size="30" text-anchor="middle" fill="%236F6A63"%3EFASHION%3C/text%3E%3C/svg%3E'
};

window.api = {
  async getProducts() { return Promise.resolve(window.PRODUCTS); },
  async getProduct(id) { return Promise.resolve(window.PRODUCTS.find(p => p.id === id)); },
  async postCart(payload) { return Promise.resolve({ ok: true, data: payload, demo: true }); },
  async postOrder(payload) { return Promise.resolve({ ok: true, data: payload, demo: true }); },
  async postWishlist(payload) { return Promise.resolve({ ok: true, data: payload, demo: true }); }
};
