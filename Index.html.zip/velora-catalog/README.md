# VÉLORA storefront

A zero-build, production-style fashion commerce frontend with responsive storefront, shopping flows, account pages and an owner dashboard.

## Edit the brand

Update `assets/js/config.js` for the brand name, logo text, palette, contact details, currency, social links and delivery threshold.

## Edit the catalogue

Update `assets/js/data.js`. Products use a reusable schema with identity, taxonomy, imagery, pricing, variants, ratings, inventory, materials, care details and merchandising flags.

## Backend integration

The `window.api` abstraction in `assets/js/config.js` defines the storefront boundary for products, cart, orders and wishlist. Replace the demo Promise methods with calls to secured Node.js / Express endpoints. Never process real card credentials in this frontend.

## Routes

The site uses hash routes so deep navigation works on any static host without rewrite configuration. Storefront, category, product, search, bag, checkout, account, order, policy and admin views are rendered from reusable functions and shared data.
